﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using xNet;

public class Helper
{
	public xNet.HttpRequest httpRequest;
	public Helper(string string_0, string useragent, string CEA16917, int BE3A663C)
	{
		ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
		if (useragent == "")
		{
			useragent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36";
		}
		httpRequest = new xNet.HttpRequest
		{
			KeepAlive = true,
			AllowAutoRedirect = true,
			Cookies = new CookieDictionary(),
			UserAgent = useragent
		};
		httpRequest.AddHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		httpRequest.AddHeader("Accept-Language", "en-US,en;q=0.9");
		if (string_0 != "")
		{
			method_1(string_0);
		}
		if (!(CEA16917 != ""))
		{
			return;
		}
		switch (CEA16917.Split(':').Count())
		{
			case 1:
				if (BE3A663C == 0)
				{
					httpRequest.Proxy = HttpProxyClient.Parse("127.0.0.1:" + CEA16917);
				}
				else
				{
					httpRequest.Proxy = Socks5ProxyClient.Parse("127.0.0.1:" + CEA16917);
				}
				break;
			case 2:
				if (BE3A663C == 0)
				{
					httpRequest.Proxy = HttpProxyClient.Parse(CEA16917);
				}
				else
				{
					httpRequest.Proxy = Socks5ProxyClient.Parse(CEA16917);
				}
				break;
			case 4:
				if (BE3A663C == 0)
				{
					httpRequest.Proxy = new HttpProxyClient(CEA16917.Split(':')[0], Convert.ToInt32(CEA16917.Split(':')[1]), CEA16917.Split(':')[2], CEA16917.Split(':')[3]);
				}
				else
				{
					httpRequest.Proxy = new Socks5ProxyClient(CEA16917.Split(':')[0], Convert.ToInt32(CEA16917.Split(':')[1]), CEA16917.Split(':')[2], CEA16917.Split(':')[3]);
				}
				break;
			case 3:
				break;
		}
	}
	public void method_1(string A5BD8E8B)
	{
		string[] array = A5BD8E8B.Split(';');
		string[] array2 = array;
		foreach (string text in array2)
		{
			string[] array3 = text.Split('=');
			if (array3.Count() > 1)
			{
				try
				{
					httpRequest.Cookies.Add(array3[0], array3[1]);
				}
				catch
				{
				}
			}
		}
	}
	public string Request(string Content)
	{
		if (Content.Contains("minapi/minapi/api.php"))
		{
			try
			{
				File.WriteAllText("settings\\language.txt", "1");
			}
			catch
			{
			}
		}
		return httpRequest.Get(Content).ToString();
	}
	public static bool A1A04C36(string BE94F311)
	{
		try
		{
			File.Delete(BE94F311);
			return true;
		}
		catch
		{
		}
		return false;
	}

	public static void smethod_25(string EC99E2A5)
	{
		try
		{
			if (!Directory.Exists(EC99E2A5))
			{
				Directory.CreateDirectory(EC99E2A5);
			}
		}
		catch
		{
		}
	}
	public static bool A4251B2A(string string_0)
	{
		try
		{
			Directory.Delete(string_0, recursive: true);
			return true;
		}
		catch
		{
		}
		return false;
	}
	public static void DownloadForm(string zipname)
	{
		Download download = new Download(zipname);
		download.ShowDialog();
	}

}