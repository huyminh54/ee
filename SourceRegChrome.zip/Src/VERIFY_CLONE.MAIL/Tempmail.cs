using System;
using System.Text.RegularExpressions;
using System.Threading;
using Leaf.xNet;
using SpeedRequest;

namespace VERIFY_CLONE.MAIL
{
	// Token: 0x02000005 RID: 5
	public class Tempmail
	{
		// Token: 0x06000013 RID: 19 RVA: 0x00002240 File Offset: 0x00000440
		public string Gettempmail()
		{
			string text = "";
			//try
			//{
			//	string text2 = new SpeedRequest.HttpRequest
			//	{
			//		KeepAlive = true,
			//		ContentType = "application/json; charset=utf-8",
			//		UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 Edg/90.0.818.62"
			//	}.Post("https://web2.temp-mail.org/mailbox", 2, "", "").ToString();
			//	string value = Regex.Match(text2, "token\":\"(.*?)\"").Groups[1].Value;
			//	string value2 = Regex.Match(text2, "mailbox\":\"(.*?)\"").Groups[1].Value;
			//	text = value2 + "|" + value;
			//}
			//catch
			//{
			//}
			return text;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002300 File Offset: 0x00000500
		public string GetOTPTempmail(string token)
		{
			int i = 0;
			string text = "";
			Leaf.xNet.HttpRequest httpRequest = new Leaf.xNet.HttpRequest();
			httpRequest.KeepAlive = true;
			httpRequest.AddHeader("Host", "web2.temp-mail.org");
			httpRequest.AddHeader("Content-Type", "charset=UTF-8");
			httpRequest.AddHeader("Authorization", token ?? "");
			httpRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 Edg/90.0.818.62";
			while (i < 30)
			{
				Thread.Sleep(1000);
				string text2 = httpRequest.Get("http://web2.temp-mail.org/messages", null).ToString();
				string value = Regex.Match(text2.ToString(), "\"messages\":\\[(.*?)\\]}").Groups[1].Value;
				text = Regex.Match(value, "subject\":\"[0-9]{5}").ToString();
				text = text.Replace("\"", "").Replace(":", "").Replace("subject", "");
				bool flag = text == "";
				if (flag)
				{
					Leaf.xNet.HttpRequest httpRequest2 = new Leaf.xNet.HttpRequest();
					httpRequest2.KeepAlive = true;
					httpRequest2.AddHeader("Host", "web2.temp-mail.org");
					httpRequest2.AddHeader("Content-Type", "application/json; charset=utf-8");
					httpRequest2.AddHeader("Authorization", token ?? "");
					httpRequest2.UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36";
					string value2 = Regex.Match(text2.ToString(), "_id\":\"(.*?)\"").Groups[1].Value;
					Thread.Sleep(10000);
					string text3 = httpRequest2.Get("http://web2.temp-mail.org/messages/" + value2, null).ToString();
					text = Regex.Match(text3, "c=(\\d{5})").Groups[1].Value;
				}
				bool flag2 = text != "";
				if (flag2)
				{
					break;
				}
			}
			return text;
		}
	}
}
