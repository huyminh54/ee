using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CloneFacebook.ChildForm
{
	public class AddGhiChu : Form
	{
		public static string noidung = "";

		private IContainer components = null;

		private Button btn_huy;

		private Button btn_add;

		private Label label1;

		private TextBox txt_noidung;

		public AddGhiChu()
		{
			InitializeComponent();
		}

		private void btn_add_Click(object sender, EventArgs e)
		{
			if (txt_noidung.Text != "")
			{
				noidung = txt_noidung.Text;
				Close();
			}
			else
			{
				MessageBox.Show("Chưa nhập nội dung !", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		private void btn_huy_Click(object sender, EventArgs e)
		{
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CloneFacebook.ChildForm.AddGhiChu));
			this.btn_huy = new System.Windows.Forms.Button();
			this.btn_add = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.txt_noidung = new System.Windows.Forms.TextBox();
			base.SuspendLayout();
			this.btn_huy.BackColor = System.Drawing.Color.Transparent;
			this.btn_huy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_huy.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.btn_huy.ForeColor = System.Drawing.Color.Maroon;
			this.btn_huy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_huy.Location = new System.Drawing.Point(72, 89);
			this.btn_huy.Name = "btn_huy";
			this.btn_huy.Size = new System.Drawing.Size(91, 26);
			this.btn_huy.TabIndex = 97;
			this.btn_huy.Text = "Hủy";
			this.btn_huy.UseVisualStyleBackColor = false;
			this.btn_huy.Click += new System.EventHandler(btn_huy_Click);
			this.btn_add.BackColor = System.Drawing.Color.Transparent;
			this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_add.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.btn_add.ForeColor = System.Drawing.Color.DodgerBlue;
			this.btn_add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_add.Location = new System.Drawing.Point(169, 89);
			this.btn_add.Name = "btn_add";
			this.btn_add.Size = new System.Drawing.Size(91, 26);
			this.btn_add.TabIndex = 96;
			this.btn_add.Text = "Thêm";
			this.btn_add.UseVisualStyleBackColor = false;
			this.btn_add.Click += new System.EventHandler(btn_add_Click);
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = System.Drawing.Color.FromArgb(26, 115, 233);
			this.label1.Location = new System.Drawing.Point(38, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(55, 13);
			this.label1.TabIndex = 95;
			this.label1.Text = "Nội dung";
			this.txt_noidung.BackColor = System.Drawing.Color.FromArgb(64, 64, 64);
			this.txt_noidung.ForeColor = System.Drawing.Color.FromArgb(224, 224, 224);
			this.txt_noidung.Location = new System.Drawing.Point(30, 48);
			this.txt_noidung.Name = "txt_noidung";
			this.txt_noidung.Size = new System.Drawing.Size(273, 20);
			this.txt_noidung.TabIndex = 94;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(335, 154);
			base.Controls.Add(this.btn_huy);
			base.Controls.Add(this.btn_add);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.txt_noidung);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "AddGhiChu";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Thêm ghi chú";
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
