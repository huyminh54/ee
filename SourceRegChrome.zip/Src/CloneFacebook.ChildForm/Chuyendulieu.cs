using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ChangerClone;

namespace CloneFacebook.ChildForm
{
	public class Chuyendulieu : Form
	{
		public static bool action;

		public static string name;

		private IContainer components = null;

		private ComboBox combobox_namedanhmuc;

		private Button btn_huy;

		private Button btn_add;

		private Label label1;

		public Chuyendulieu()
		{
			InitializeComponent();
		}

		public void LoadDanhMuc()
		{
			Invoke((Action)delegate
			{
				combobox_namedanhmuc.Items.Clear();
			});
			List<string> dm = SQLite.getlistdanhmuc("DM");
			int i;
			for (i = 0; i < dm.Count; i++)
			{
				Invoke((Action)delegate
				{
					combobox_namedanhmuc.Items.Add(dm[i]);
				});
			}
		}

		private void btn_add_Click(object sender, EventArgs e)
		{
			action = true;
			name = combobox_namedanhmuc.Text;
			Close();
		}

		private void Chuyendulieu_Load(object sender, EventArgs e)
		{
			LoadDanhMuc();
		}

		private void btn_huy_Click(object sender, EventArgs e)
		{
			action = false;
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CloneFacebook.ChildForm.Chuyendulieu));
			this.combobox_namedanhmuc = new System.Windows.Forms.ComboBox();
			this.btn_huy = new System.Windows.Forms.Button();
			this.btn_add = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			base.SuspendLayout();
			this.combobox_namedanhmuc.BackColor = System.Drawing.Color.FromArgb(64, 64, 64);
			this.combobox_namedanhmuc.ForeColor = System.Drawing.Color.FromArgb(224, 224, 224);
			this.combobox_namedanhmuc.FormattingEnabled = true;
			this.combobox_namedanhmuc.Location = new System.Drawing.Point(43, 46);
			this.combobox_namedanhmuc.Name = "combobox_namedanhmuc";
			this.combobox_namedanhmuc.Size = new System.Drawing.Size(188, 21);
			this.combobox_namedanhmuc.TabIndex = 98;
			this.btn_huy.BackColor = System.Drawing.Color.Transparent;
			this.btn_huy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_huy.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.btn_huy.ForeColor = System.Drawing.Color.Maroon;
			this.btn_huy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_huy.Location = new System.Drawing.Point(43, 88);
			this.btn_huy.Name = "btn_huy";
			this.btn_huy.Size = new System.Drawing.Size(91, 26);
			this.btn_huy.TabIndex = 97;
			this.btn_huy.Text = "HỦY";
			this.btn_huy.UseVisualStyleBackColor = false;
			this.btn_huy.Click += new System.EventHandler(btn_huy_Click);
			this.btn_add.BackColor = System.Drawing.Color.Transparent;
			this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_add.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.btn_add.ForeColor = System.Drawing.Color.DodgerBlue;
			this.btn_add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_add.Location = new System.Drawing.Point(140, 88);
			this.btn_add.Name = "btn_add";
			this.btn_add.Size = new System.Drawing.Size(91, 26);
			this.btn_add.TabIndex = 96;
			this.btn_add.Text = "OK";
			this.btn_add.UseVisualStyleBackColor = false;
			this.btn_add.Click += new System.EventHandler(btn_add_Click);
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Tahoma", 7f, System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = System.Drawing.Color.Black;
			this.label1.Location = new System.Drawing.Point(40, 29);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(85, 12);
			this.label1.TabIndex = 95;
			this.label1.Text = "TÊN DANH MỤC";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(280, 159);
			base.Controls.Add(this.combobox_namedanhmuc);
			base.Controls.Add(this.btn_huy);
			base.Controls.Add(this.btn_add);
			base.Controls.Add(this.label1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "Chuyendulieu";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Chuyển data";
			base.Load += new System.EventHandler(Chuyendulieu_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
