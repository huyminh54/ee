using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using ChangerClone;

namespace CloneFacebook.ChildForm
{
	public class AddDanhmuc : Form
	{
		public static bool FAceytQozKcOwUyPaYSsUFAcikakyh;

		private IContainer components = null;

		private Button btn_huy;

		private Button btn_add;

		private Label label1;

		private TextBox txt_danhmuc;

		public AddDanhmuc()
		{
			InitializeComponent();
		}

		private void btn_add_Click(object sender, EventArgs e)
		{
			List<string> list = SQLite.getlistdanhmuc("DM");
			foreach (string item in list)
			{
				if (!(item.ToString() == txt_danhmuc.Text))
				{
					continue;
				}
				MessageBox.Show("Already exist category : " + txt_danhmuc.Text, "NOTIFICATIONS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				goto IL_009e;
			}
			SQLite.insertdm(txt_danhmuc.Text);
			FAceytQozKcOwUyPaYSsUFAcikakyh = true;
			Close();
			goto IL_009e;
			IL_009e:
			Thread.Sleep(1);
		}

		private void btn_huy_Click(object sender, EventArgs e)
		{
			FAceytQozKcOwUyPaYSsUFAcikakyh = false;
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CloneFacebook.ChildForm.AddDanhmuc));
			this.btn_huy = new System.Windows.Forms.Button();
			this.btn_add = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.txt_danhmuc = new System.Windows.Forms.TextBox();
			base.SuspendLayout();
			this.btn_huy.BackColor = System.Drawing.Color.Transparent;
			this.btn_huy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_huy.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.btn_huy.ForeColor = System.Drawing.Color.Maroon;
			this.btn_huy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_huy.Location = new System.Drawing.Point(104, 93);
			this.btn_huy.Name = "btn_huy";
			this.btn_huy.Size = new System.Drawing.Size(91, 26);
			this.btn_huy.TabIndex = 93;
			this.btn_huy.Text = "Hủy";
			this.btn_huy.UseVisualStyleBackColor = false;
			this.btn_huy.Click += new System.EventHandler(btn_huy_Click);
			this.btn_add.BackColor = System.Drawing.Color.Transparent;
			this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_add.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.btn_add.ForeColor = System.Drawing.Color.DodgerBlue;
			this.btn_add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_add.Location = new System.Drawing.Point(201, 93);
			this.btn_add.Name = "btn_add";
			this.btn_add.Size = new System.Drawing.Size(91, 26);
			this.btn_add.TabIndex = 92;
			this.btn_add.Text = "Thêm";
			this.btn_add.UseVisualStyleBackColor = false;
			this.btn_add.Click += new System.EventHandler(btn_add_Click);
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = System.Drawing.Color.Black;
			this.label1.Location = new System.Drawing.Point(60, 36);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(86, 13);
			this.label1.TabIndex = 91;
			this.label1.Text = "Tên Danh Mục";
			this.txt_danhmuc.BackColor = System.Drawing.Color.FromArgb(64, 64, 64);
			this.txt_danhmuc.ForeColor = System.Drawing.Color.FromArgb(224, 224, 224);
			this.txt_danhmuc.Location = new System.Drawing.Point(63, 52);
			this.txt_danhmuc.Name = "txt_danhmuc";
			this.txt_danhmuc.Size = new System.Drawing.Size(273, 20);
			this.txt_danhmuc.TabIndex = 90;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(397, 155);
			base.Controls.Add(this.btn_huy);
			base.Controls.Add(this.btn_add);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.txt_danhmuc);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "AddDanhmuc";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Thêm danh mục";
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
