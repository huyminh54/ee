using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using FBAutoKitDo.Helper;
using Newtonsoft.Json.Linq;
using Proxy_Client_Tinsoft;
using TMProxyHelper;

namespace Demon_System
{
	internal class ChangeIP_Helper
	{
		public static List<string> API_on = new List<string>();

		public static List<string> API_done = new List<string>();

		public static bool getip = true;

		private static TinsoftProxy myProxy;

		public static object obj = new object();

		public static string ChangeDCOM(string DCOM_Name)
		{
			string text = "";
			try
			{
				NetHelper.resetDcom(DCOM_Name);
				NetHelper.startDcom(DCOM_Name);
				int num = 0;
				while (true)
				{
					NetHelper netHelper = new NetHelper();
					text = netHelper.CheckIP();
					if (text != "" || num == 10)
					{
						break;
					}
					num++;
					Thread.Sleep(1000);
				}
			}
			catch
			{
			}
			return text;
		}

		public static string tinsoft(string API)
		{
			if (myProxy == null)
			{
				myProxy = new TinsoftProxy("");
			}
			myProxy.api_key = API;
			myProxy.location = 0;
			string text = "";
			while (!myProxy.changeProxy())
			{
				Thread.Sleep(10000);
			}
			return myProxy.proxy;
		}

		public static string Sproxy(string API, string location)
		{
			string text = "";
			while (true)
			{
				NetHelper netHelper = new NetHelper();
				string text2 = "http://proxy.shoplike.vn/Api/getNewProxy?access_token=" + API;
				if (location != "")
				{
					text2 = text2 + "&location=" + location;
				}
				string text3 = netHelper.RequestGet(text2);
				if (text3.Contains("success"))
				{
					JObject jObject = JObject.Parse(text3);
					string text4 = JObject.Parse(JObject.Parse(text3)["data"]!.ToString())["proxy"]!.ToString();
					if (text4 != "")
					{
						return text4;
					}
				}
				else
				{
					if (text3.Contains("Con lai"))
					{
						return "Đợi " + Convert.ToInt32(Regex.Match(text3, "Con lai (.*?) giay").Groups[1].Value);
					}
					if (text3.Contains("het han"))
					{
						break;
					}
				}
				Thread.Sleep(1);
			}
			return "hethan";
		}

		public static bool CheckSproxy(string API)
		{
			bool result = false;
			while (true)
			{
				try
				{
					NetHelper netHelper = new NetHelper();
					string url = "http://proxy.shoplike.vn/Api/getCurrentProxy?access_token=" + API;
					string text = netHelper.RequestGet(url);
					if (text.Contains("success") || text.Contains("Het") || text.Contains("Con lai"))
					{
						result = true;
					}
				}
				catch
				{
					Thread.Sleep(100);
					continue;
				}
				break;
			}
			return result;
		}

		public static string tmproxy(string API)
		{
			string result = "";
			while (true)
			{
				List<string> list = new List<string>();
				string newProxy = TMAPIHelper.GetNewProxy(API, "string", "5");
				try
				{
					JObject jObject = JObject.Parse(newProxy);
					list.Add(jObject["message"]!.ToString());
					JToken jToken = jObject["data"];
					if (jToken != null)
					{
						list.Add(jToken["https"]!.ToString());
					}
					if (list[0] == "")
					{
						result = list[1];
					}
					else if (list[0].Contains("retry"))
					{
						int[] array = (from m in Regex.Matches(list[0], "\\d+").OfType<Match>()
							select int.Parse(m.Value)).ToArray();
						result = "wait|" + Convert.ToInt32(array[0].ToString());
					}
					else if (list[0].ToLower().Contains("hết"))
					{
						result = "TMProxy Hết Hạn";
					}
				}
				catch
				{
					continue;
				}
				break;
			}
			return result;
		}

		public static string ChangeIP_API(List<string> listAPI, int numLuong, int numreset, bool reset, string IPsetting)
		{
			string text = "";
			lock (obj)
			{
				if (listAPI.Count > 0)
				{
					bool flag = true;
					while (true)
					{
						IL_0030:
						int num = 0;
						int num2 = 0;
						while (true)
						{
							if (num2 < listAPI.Count)
							{
								string text2 = listAPI[num2];
								if (text2 != "")
								{
									switch (checkdone(numLuong, numreset, reset, API_on, API_done, text2))
									{
									case "ok":
										if (IPsetting.Contains("TINSOFT"))
										{
											text = tinsoft(text2);
										}
										else if (IPsetting.Contains("SPROXY"))
										{
											while (true)
											{
												text = Sproxy(text2, IPsetting.Split('|')[2]);
												if (!text.Contains("Đợi"))
												{
													break;
												}
												int num3 = Convert.ToInt32(text.Replace("Đợi ", ""));
												Thread.Sleep(num3 * 1000);
											}
											if (text.Contains("hethan"))
											{
												num++;
												break;
											}
										}
										else if (IPsetting.Contains("TMPROXY"))
										{
											text = tmproxy(text2);
										}
										if (text.Contains("wait") || text.Contains("Hết") || !checkuse(text2, numLuong, API_on))
										{
											break;
										}
										API_on.Add(text2 + "|" + text);
										text = text2 + "|" + text;
										goto end_IL_03fa;
									case "ok1":
										foreach (string item in API_on)
										{
											if (item.ToString().Split('|')[0] == text2)
											{
												text = item.ToString().Split('|')[1];
												API_on.Add(text2 + "|" + text);
												text = text2 + "|" + text;
												return text;
											}
										}
										break;
									case "ok3":
										foreach (string item2 in API_on)
										{
											if (!(item2.ToString().Split('|')[0] == text2))
											{
												continue;
											}
											text = item2.ToString().Split('|')[1];
											for (int i = 0; i < API_on.Count; i++)
											{
												if (API_on[i].Split('|')[0] == text2)
												{
													API_on.RemoveAt(i);
													i--;
												}
											}
											API_on.Add(text2 + "|" + text);
											text = text2 + "|" + text;
											return text;
										}
										break;
									}
								}
								Thread.Sleep(100);
								num2++;
								continue;
							}
							if (num == listAPI.Count)
							{
								MessageBox.Show("Tất cả API hết hạn hoặc không tồn tại !", "", MessageBoxButtons.OK, MessageBoxIcon.Hand);
								break;
							}
							Thread.Sleep(100);
							goto IL_0030;
							continue;
							end_IL_03fa:
							break;
						}
						break;
					}
				}
			}
			return text;
		}

		public static void AddDone(string API)
		{
			API_done.Add(API);
		}

		public static string checkdone(int num, int numreset, bool reset, List<string> API_on, List<string> API_done, string API)
		{
			string result = "";
			while (true)
			{
				try
				{
					int num2 = API_on.Count((string s) => s.Contains(API));
					if (num2 >= num)
					{
						int num3 = API_done.Count((string s) => s.Contains(API));
						if (reset && num3 >= num * numreset)
						{
							for (int i = 0; i < API_on.Count; i++)
							{
								if (API_on[i].Split('|')[0] == API)
								{
									API_on.RemoveAt(i);
									i--;
								}
							}
							for (int j = 0; j < API_done.Count; j++)
							{
								if (API_done[j].Split('|')[0] == API)
								{
									API_done.RemoveAt(j);
									j--;
								}
							}
							result = "ok";
						}
						else if (num3 == num)
						{
							result = "ok3";
						}
					}
					else if (num2 == 0)
					{
						result = "ok";
					}
					else if (num2 < num)
					{
						result = "ok1";
					}
				}
				catch
				{
					continue;
				}
				break;
			}
			return result;
		}

		public static void clear()
		{
			API_done.Clear();
			API_on.Clear();
		}

		public static bool checkuse(string API, int num, List<string> API_on)
		{
			int num2 = API_on.Count((string s) => s.Contains(API));
			if (num2 < num)
			{
				return true;
			}
			return false;
		}

		public static string HMA(string HMA)
		{
			string result = "";
			try
			{
				NetHelper netHelper = new NetHelper();
				string text = netHelper.CheckIP();
				disablehma();
				enablehma();
				Thread.Sleep(10000);
				string text2;
				do
				{
					NetHelper netHelper2 = new NetHelper();
					text2 = netHelper2.CheckIP();
				}
				while (text2 == text || text2 == HMA);
				result = text2;
				Thread.Sleep(2000);
			}
			catch
			{
			}
			return result;
		}

		public static void enablehma()
		{
			string text = "netsh interface set interface \"HMA! Pro VPN OpenVPN\" enable";
			Process process = new Process();
			process.StartInfo = new ProcessStartInfo
			{
				FileName = "cmd.exe",
				Arguments = "/c" + text,
				UseShellExecute = false,
				WindowStyle = ProcessWindowStyle.Hidden,
				CreateNoWindow = true,
				RedirectStandardError = true,
				RedirectStandardInput = true,
				RedirectStandardOutput = true
			};
			process.Start();
		}

		public static void disablehma()
		{
			string text = "netsh interface set interface \"HMA! Pro VPN OpenVPN\" disable";
			Process process = new Process();
			process.StartInfo = new ProcessStartInfo
			{
				FileName = "cmd.exe",
				Arguments = "/c" + text,
				UseShellExecute = false,
				WindowStyle = ProcessWindowStyle.Hidden,
				CreateNoWindow = true,
				RedirectStandardError = true,
				RedirectStandardInput = true,
				RedirectStandardOutput = true
			};
			process.Start();
		}

		public static string Nord(string nameNord)
		{
			string text = "";
			NetHelper netHelper = new NetHelper();
			string text2 = netHelper.CheckIP();
			while (true)
			{
				Random random = new Random();
				string[] array = new string[23]
				{
					"United States", "United Kingdom", "Spain", "Sweden", "Switzerland", "Taiwan", "Singapore", "Norway", "North Macedonia", "Netherlands",
					"Japan", "Italy", "Israel", "Ireland", "India", "Hungary", "Hong Kong", "Germany", "France", "Denmark",
					"Canada", "Belgium", "Australia"
				};
				string text3 = array[random.Next(0, array.Length)];
				string text4 = nameNord + "\\nordvpn -c -g \"" + text3 + "\"";
				Process process = new Process();
				process.StartInfo = new ProcessStartInfo
				{
					FileName = "cmd.exe",
					Arguments = "/c" + text4,
					UseShellExecute = false,
					WindowStyle = ProcessWindowStyle.Hidden,
					CreateNoWindow = true,
					RedirectStandardError = true,
					RedirectStandardInput = true,
					RedirectStandardOutput = true
				};
				process.Start();
				Thread.Sleep(5000);
				int num = 0;
				while (true)
				{
					NetHelper netHelper2 = new NetHelper();
					string text5 = netHelper2.CheckIP();
					if (text5 == text2)
					{
						if (num == 6)
						{
							break;
						}
						Thread.Sleep(5000);
						num++;
					}
					else if (!(text5 == ""))
					{
						text = text5;
						Thread.Sleep(2000);
						return text;
					}
				}
			}
		}
	}
}
