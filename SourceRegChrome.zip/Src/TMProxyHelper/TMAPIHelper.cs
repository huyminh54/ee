using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using RestSharp;

namespace TMProxyHelper
{
	public static class TMAPIHelper
	{
		private static string url = "https://tmproxy.com/api/proxy";

		public static string Stats(string key)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Expected O, but got Unknown
			var value = new
			{
				api_key = key
			};
			string data = JsonConvert.SerializeObject(value);
			string text = PostDataJson(new HttpClient(), url + "/stats", data);
			Console.WriteLine(text);
			return text;
		}

		public static string GetCurrentProxy(string key)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Expected O, but got Unknown
			var value = new
			{
				api_key = key
			};
			string data = JsonConvert.SerializeObject(value);
			string text = PostDataJson(new HttpClient(), url + "/get-current-proxy", data);
			Console.WriteLine(text);
			return text;
		}

		public static string GetNewProxy(string key, string sign, string session)
		{
			RestClient restClient = new RestClient("https://tmproxy.com/api/proxy/get-new-proxy");
			restClient.Timeout = -1;
			RestRequest restRequest = new RestRequest(Method.POST);
			restRequest.AddHeader("Content-Type", "application/json");
			string value = "{\"api_key\": \"" + key + "\",\"id_location\": 1}";
			restRequest.AddParameter("application/json", value, ParameterType.RequestBody);
			IRestResponse restResponse = restClient.Execute(restRequest);
			return restResponse.Content;
		}

		public static string CheckstatusProxy(string key)
		{
			RestClient restClient = new RestClient("https://tmproxy.com/api/proxy/stats");
			restClient.Timeout = -1;
			RestRequest restRequest = new RestRequest(Method.POST);
			restRequest.AddHeader("Content-Type", "application/json");
			string value = "{\"api_key\": \"" + key + "\"}";
			restRequest.AddParameter("application/json", value, ParameterType.RequestBody);
			IRestResponse restResponse = restClient.Execute(restRequest);
			return restResponse.Content;
		}

		public static string PostDataJson(HttpClient httpClient, string url, string data = null)
		{
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Expected O, but got Unknown
			HttpContent c;
			while (true)
			{
				ServicePointManager.Expect100Continue = true;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
				string text = "";
				c = (HttpContent)new StringContent(data, Encoding.UTF8, "application/json");
				try
				{
					Task<string> task = Task.Run(() => PostURI(new Uri(url), c));
					task.Wait();
					return task.Result;
				}
				catch
				{
				}
			}
		}

		private static async Task<string> PostURI(Uri u, HttpContent c)
		{
			string response = string.Empty;
			HttpClient client = new HttpClient();
			try
			{
				HttpResponseMessage result = await client.PostAsync(u, c);
				if (result.IsSuccessStatusCode)
				{
					response = await result.Content.ReadAsStringAsync();
				}
				return response;
			}
			finally
			{
				((IDisposable)client)?.Dispose();
			}
		}
	}
}
