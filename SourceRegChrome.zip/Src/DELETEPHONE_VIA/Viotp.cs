using System.Text.RegularExpressions;
using xNet;

namespace DELETEPHONE_VIA
{
	public class Viotp
	{
		public string Getphone(string APIKEY)
		{
			string result = "";
			string address = "https://api.viotp.com/request/get?token=" + APIKEY + "&serviceId=7";
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					string value = Regex.Match(input, "phone_number\":\"([0-9]{0,})").Groups[1].Value;
					string value2 = Regex.Match(input, "request_id\":([0-9]{0,})").Groups[1].Value;
					result = value + "|" + value2;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}

		public string Getphone_network(string APIKEY, string nhamang)
		{
			string result = "";
			string address = "https://api.viotp.com/request/get?token=" + APIKEY + "&serviceId=7&network=" + nhamang;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					string value = Regex.Match(input, "phone_number\":\"([0-9]{0,})").Groups[1].Value;
					string value2 = Regex.Match(input, "request_id\":([0-9]{0,})").Groups[1].Value;
					result = value + "|" + value2;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}

		public string Getcode(string APIKEY, string IDPHONE)
		{
			string result = "";
			string address = "https://api.viotp.com/session/get?requestId=" + IDPHONE + "&token=" + APIKEY;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					result = Regex.Match(input, "Code\":\"([0-9]{0,})").Groups[1].Value;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}
	}
}
