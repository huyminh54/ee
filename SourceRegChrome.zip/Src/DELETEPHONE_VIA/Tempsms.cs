using System.Text.RegularExpressions;
using xNet;

namespace DELETEPHONE_VIA
{
	public class Tempsms
	{
		public void Canelphone(string APIKEY, string idrequest)
		{
			string address = "https://api.tempsms.co/cancel?api_key=" + APIKEY + "&request_id=" + idrequest;
			using HttpRequest httpRequest = new HttpRequest();
			try
			{
				string text = httpRequest.Get(address).ToString();
			}
			catch
			{
			}
		}

		public string Get_id_request(string APIKEY, string service)
		{
			string result = "";
			string address = "https://api.tempsms.co/create?api_key=" + APIKEY + "&service_id=" + service;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					result = Regex.Match(input, "request_id\":([0-9]{0,})").Groups[1].Value;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}

		public string GetphoneFromID(string API, string idrequest)
		{
			string result = "";
			string address = "https://api.tempsms.co/detail?api_key=" + API + "&request_id=" + idrequest;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					result = Regex.Match(input, "phone\":\"(.*?)\"").Groups[1].Value;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}

		public string Getcode(string APIKEY, string IDPHONE)
		{
			string result = "";
			string address = "https://api.tempsms.co/detail?api_key=" + APIKEY + "&request_id=" + IDPHONE;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					result = Regex.Match(input, "otp\":\"(.*?)\"").Groups[1].Value;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}
	}
}
