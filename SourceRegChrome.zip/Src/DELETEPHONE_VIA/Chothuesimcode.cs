using System.Text.RegularExpressions;
using System.Threading;
using xNet;

namespace DELETEPHONE_VIA
{
	public class Chothuesimcode
	{
		public string Getphone(string APIKEY, string service)
		{
			string result = "";
			string address = "https://chothuesimcode.com/api?act=number&apik=" + APIKEY + "&appId=1001&carrier=VNMB";
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					string value = Regex.Match(input, "Number\":\"([0-9]{0,})").Groups[1].Value;
					string value2 = Regex.Match(input, "Id\":([0-9]{0,})").Groups[1].Value;
					result = value + "|" + value2;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}

		public string Getphone_theomang(string APIKEY, string nhamang)
		{
			string result = "";
			string address = "https://chothuesimcode.com/api?act=number&apik=" + APIKEY + "&appId=1001&carrier=" + nhamang;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					string value = Regex.Match(input, "Number\":\"([0-9]{0,})").Groups[1].Value;
					string value2 = Regex.Match(input, "Id\":([0-9]{0,})").Groups[1].Value;
					result = value + "|" + value2;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}

		public void Canelphone(string APIKEY, string IDPHONE)
		{
			string address = "https://chothuesimcode.com/api?act=expired&apik=" + APIKEY + "&id=" + IDPHONE;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string text = httpRequest.Get(address).ToString();
				}
				catch
				{
				}
			}
			Thread.Sleep(300);
		}

		public string Getcode(string APIKEY, string IDPHONE)
		{
			string result = "";
			string address = "https://chothuesimcode.com/api?act=code&apik=" + APIKEY + "&id=" + IDPHONE;
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					string input = httpRequest.Get(address).ToString();
					result = Regex.Match(input, "Code\":\"([0-9]{0,})").Groups[1].Value;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}
	}
}
