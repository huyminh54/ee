namespace FBAUTOKITDO_System
{
	internal class S_PROXY
	{
		public static string GetNewProxy(string API, string Location)
		{
			return "";
		}
	}
}
