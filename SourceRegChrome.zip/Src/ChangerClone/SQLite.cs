using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Diagnostics;
using System.Text;
using System.Threading;

namespace ChangerClone
{
	internal class SQLite
	{
		public static void insert(string cateloge, string data)
		{
			string[] array = data.Split(new string[1] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
			List<string> list = getlistac(cateloge);
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			SQLiteCommand sQLiteCommand = new SQLiteCommand(sQLiteConnection);
			SQLiteTransaction sQLiteTransaction2 = (sQLiteCommand.Transaction = sQLiteConnection.BeginTransaction());
			SQLiteTransaction sQLiteTransaction3 = sQLiteTransaction2;
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			for (int i = 0; i < array.Length; i++)
			{
				bool flag = false;
				foreach (string item in list)
				{
					if (array[i].Split('|')[0] == item.ToString().Split('|')[0])
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					try
					{
						string[] array2 = array[i].Split('|');
						string text = "";
						string text3 = (sQLiteCommand.CommandText = ((array2.Length != 17) ? string.Format("INSERT INTO data ('CATELOGE', 'UID','PASS','2FA','COOKIE','TOKEN','EMAIL','PASSMAIL','UA','SINHNHAT','GENDER','FRIEND','GROUP','LIVE','GHICHU','LASTACTIVE','PROXY','TRANGTHAI') VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}')", cateloge, array2[0], array2[1], array2[2], array2[3], array2[4], array2[5], array2[6], array2[7], array2[8], array2[9], array2[10], array2[11], array2[12], array2[13], array2[14], array2[15], "") : ("INSERT INTO data ('CATELOGE', 'UID','PASS','2FA','COOKIE','TOKEN','EMAIL','PASSMAIL','UA','SINHNHAT','GENDER','FRIEND','GROUP','LIVE','GHICHU','LASTACTIVE','PROXY','TRANGTHAI') VALUES ('" + cateloge + "','" + array2[0] + "','" + array2[1] + "','" + array2[2] + "','" + array2[3] + "','" + array2[4] + "','" + array2[5] + "','" + array2[6] + "','" + array2[7] + "','" + array2[8] + "','" + array2[9] + "','" + array2[10] + "','" + array2[11] + "','" + array2[12] + "','" + array2[13] + "','" + array2[14] + "','" + array2[15] + "','" + array2[16] + "')")));
						text = text3;
						sQLiteCommand.ExecuteNonQuery();
					}
					catch
					{
					}
				}
			}
			sQLiteTransaction3.Commit();
			stopwatch.Stop();
			sQLiteConnection.Dispose();
		}

		public static void createindex()
		{
			try
			{
				string commandText = "CREATE  INDEX 'data_CATELOGE_UID_PASS_Index' ON 'data' ('CATELOGE', 'UID','PASS')";
				SQLiteConnection sQLiteConnection = new SQLiteConnection();
				sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
				sQLiteConnection.Open();
				SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
				sQLiteCommand.ExecuteNonQuery();
				sQLiteConnection.Dispose();
			}
			catch
			{
			}
		}

		public static void insertdm(string dm)
		{
			string commandText = string.Format("INSERT INTO data ('CATELOGE', 'UID') VALUES ('{0}','{1}')", "DM", dm);
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
			sQLiteCommand.ExecuteNonQuery();
			sQLiteConnection.Dispose();
		}

		public static void deleteuid(string data)
		{
			string[] array = data.Split(new string[1] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			SQLiteCommand sQLiteCommand = new SQLiteCommand(sQLiteConnection);
			SQLiteTransaction sQLiteTransaction2 = (sQLiteCommand.Transaction = sQLiteConnection.BeginTransaction());
			SQLiteTransaction sQLiteTransaction3 = sQLiteTransaction2;
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			for (int i = 0; i < array.Length; i++)
			{
				string text2 = (sQLiteCommand.CommandText = "DELETE FROM data where [UID]='" + array[i] + "'");
				string text3 = text2;
				sQLiteCommand.ExecuteNonQuery();
			}
			sQLiteTransaction3.Commit();
			stopwatch.Stop();
			sQLiteConnection.Dispose();
		}

		public static void deleteuidincateloge(string cateloge)
		{
			while (true)
			{
				Thread.Sleep(1);
				try
				{
					string commandText = "DELETE FROM data where [CATELOGE]='" + cateloge + "'";
					SQLiteConnection sQLiteConnection = new SQLiteConnection();
					sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
					sQLiteConnection.Open();
					SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
					sQLiteCommand.ExecuteNonQuery();
					sQLiteConnection.Dispose();
					break;
				}
				catch
				{
				}
				Thread.Sleep(100);
			}
		}

		public static void deletecateloge(string cateloge)
		{
			while (true)
			{
				Thread.Sleep(1);
				try
				{
					string commandText = "DELETE FROM data where [UID]='" + cateloge + "'";
					SQLiteConnection sQLiteConnection = new SQLiteConnection();
					sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
					sQLiteConnection.Open();
					SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
					sQLiteCommand.ExecuteNonQuery();
					sQLiteConnection.Dispose();
					break;
				}
				catch
				{
				}
			}
		}

		public static void chuyendulieu(string data, string newcateloge)
		{
			string[] array = data.Split('|');
			string[] array2 = array;
			string[] array3 = array2;
			foreach (string text in array3)
			{
				if (text.ToString() != "")
				{
					update(text.ToString(), "CATELOGE", newcateloge);
				}
			}
		}

		public static void update(string UID, string key, string value)
		{
			while (true)
			{
				Thread.Sleep(1);
				try
				{
					string commandText = "UPDATE data set [" + key + "]='" + value + "' where [UID]='" + UID + "'";
					SQLiteConnection sQLiteConnection = new SQLiteConnection();
					sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
					sQLiteConnection.Open();
					SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
					sQLiteCommand.ExecuteNonQuery();
					sQLiteConnection.Dispose();
					break;
				}
				catch
				{
				}
			}
		}

		public static void changecateloge(string cateloge, string newcateloge)
		{
			while (true)
			{
				Thread.Sleep(1);
				try
				{
					string commandText = "UPDATE data set [CATELOGE]='" + newcateloge + "' where [CATELOGE]='" + cateloge + "'";
					SQLiteConnection sQLiteConnection = new SQLiteConnection();
					sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
					sQLiteConnection.Open();
					SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
					sQLiteCommand.ExecuteNonQuery();
					sQLiteConnection.Dispose();
					break;
				}
				catch
				{
				}
			}
		}

		public static void updateall(string UID, string cateloge, string data)
		{
			while (true)
			{
				Thread.Sleep(1);
				try
				{
					string[] array = data.Split('|');
					string text = "";
					text = ((!array[6].Contains("'")) ? array[6] : array[6].Replace("'", "\""));
					string commandText = "UPDATE data set [PASS]='" + array[0] + "',[2FA]='" + array[1] + "',[COOKIE]='" + array[2] + "',[TOKEN]='" + array[3] + "',[EMAIL]='" + array[4] + "',[PASSMAIL]='" + array[5] + "',[UA]='" + text + "',[SINHNHAT]='" + array[7] + "',[GENDER]='" + array[8] + "',[FRIEND]='" + array[9] + "',[GROUP]='" + array[10] + "',[LIVE]='" + array[11] + "',[GHICHU]='" + array[12] + "',[LASTACTIVE]='" + array[13] + "',[PROXY]='" + array[15] + "',[TRANGTHAI]='" + array[16] + "'where [UID]='" + UID + "' and [CATELOGE]='" + cateloge + "'";
					SQLiteConnection sQLiteConnection = new SQLiteConnection();
					sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
					sQLiteConnection.Open();
					SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
					sQLiteCommand.ExecuteNonQuery();
					sQLiteConnection.Dispose();
					break;
				}
				catch
				{
				}
			}
		}

		public static void updatemail(string mail, string key, string value)
		{
			while (true)
			{
				Thread.Sleep(1);
				try
				{
					string commandText = "UPDATE data set [" + key + "]='" + value + "' where [EMAIL]='" + mail + "'";
					SQLiteConnection sQLiteConnection = new SQLiteConnection();
					sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
					sQLiteConnection.Open();
					SQLiteCommand sQLiteCommand = new SQLiteCommand(commandText, sQLiteConnection);
					sQLiteCommand.ExecuteNonQuery();
					sQLiteConnection.Dispose();
					break;
				}
				catch
				{
				}
			}
		}

		public static DataTable getlistacdt(string cateloge)
		{
			DataTable dataTable = new DataTable();
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			using (SQLiteConnection sQLiteConnection2 = sQLiteConnection)
			{
				using SQLiteCommand sQLiteCommand = sQLiteConnection2.CreateCommand();
				sQLiteCommand.CommandText = "SELECT * From [data]";
				SQLiteDataAdapter sQLiteDataAdapter = new SQLiteDataAdapter("SELECT * From [data] Where [CATELOGE] ='" + cateloge + "'", sQLiteConnection);
				sQLiteDataAdapter.Fill(dataTable);
			}
			sQLiteConnection.Dispose();
			return dataTable;
		}

		public static List<string> getlistac(string cateloge)
		{
			List<string> list = new List<string>();
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			using (SQLiteConnection sQLiteConnection2 = sQLiteConnection)
			{
				using SQLiteCommand sQLiteCommand = sQLiteConnection2.CreateCommand();
				sQLiteCommand.CommandText = "SELECT * From [data]";
				sQLiteCommand.CommandType = CommandType.Text;
				SQLiteDataReader sQLiteDataReader = sQLiteCommand.ExecuteReader();
				int num = 0;
				bool flag;
				while (flag = sQLiteDataReader.Read())
				{
					if (sQLiteDataReader["CATELOGE"].ToString() == cateloge)
					{
						num++;
						list.Add(sQLiteDataReader["UID"].ToString() + "|" + sQLiteDataReader["PASS"].ToString() + "|" + sQLiteDataReader["2FA"].ToString() + "|" + sQLiteDataReader["COOKIE"].ToString() + "|" + sQLiteDataReader["TOKEN"].ToString() + "|" + sQLiteDataReader["EMAIL"].ToString() + "|" + sQLiteDataReader["PASSMAIL"].ToString() + "|" + sQLiteDataReader["UA"].ToString() + "|" + sQLiteDataReader["SINHNHAT"].ToString() + "|" + sQLiteDataReader["GENDER"].ToString() + "|" + sQLiteDataReader["FRIEND"].ToString() + "|" + sQLiteDataReader["GROUP"].ToString() + "|" + sQLiteDataReader["LIVE"].ToString() + "|" + sQLiteDataReader["GHICHU"].ToString() + "|" + sQLiteDataReader["LASTACTIVE"].ToString() + "|" + sQLiteDataReader["TRANGTHAI"].ToString());
					}
				}
			}
			sQLiteConnection.Dispose();
			return list;
		}

		public static string getlistac1(string cateloge)
		{
			StringBuilder stringBuilder = new StringBuilder();
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			using (SQLiteConnection sQLiteConnection2 = sQLiteConnection)
			{
				using SQLiteCommand sQLiteCommand = sQLiteConnection2.CreateCommand();
				sQLiteCommand.CommandText = "SELECT * From [data]";
				sQLiteCommand.CommandType = CommandType.Text;
				SQLiteDataReader sQLiteDataReader = sQLiteCommand.ExecuteReader();
				int num = 0;
				bool flag;
				while (flag = sQLiteDataReader.Read())
				{
					if (sQLiteDataReader["CATELOGE"].ToString() == cateloge)
					{
						num++;
						stringBuilder.Append(sQLiteDataReader["UID"].ToString() + "|" + sQLiteDataReader["PASS"].ToString() + "|" + sQLiteDataReader["2FA"].ToString() + "|" + sQLiteDataReader["COOKIE"].ToString() + "|" + sQLiteDataReader["TOKEN"].ToString() + "|" + sQLiteDataReader["EMAIL"].ToString() + "|" + sQLiteDataReader["PASSMAIL"].ToString() + "|" + sQLiteDataReader["UA"].ToString() + "|" + sQLiteDataReader["SINHNHAT"].ToString() + "|" + sQLiteDataReader["GENDER"].ToString() + "|" + sQLiteDataReader["FRIEND"].ToString() + "|" + sQLiteDataReader["GROUP"].ToString() + "|" + sQLiteDataReader["LIVE"].ToString() + "|" + sQLiteDataReader["GHICHU"].ToString() + "|" + sQLiteDataReader["LASTACTIVE"].ToString() + "|" + sQLiteDataReader["CATELOGE"].ToString() + "|" + sQLiteDataReader["PROXY"].ToString() + "|" + sQLiteDataReader["TRANGTHAI"].ToString() + "\r\n");
					}
				}
			}
			sQLiteConnection.Dispose();
			return stringBuilder.ToString();
		}

		public static string getacfromuid(string uid)
		{
			string result = "";
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			using (SQLiteConnection sQLiteConnection2 = sQLiteConnection)
			{
				using SQLiteCommand sQLiteCommand = sQLiteConnection2.CreateCommand();
				sQLiteCommand.CommandText = "SELECT * From [data]";
				sQLiteCommand.CommandType = CommandType.Text;
				SQLiteDataReader sQLiteDataReader = sQLiteCommand.ExecuteReader();
				bool flag;
				while (flag = sQLiteDataReader.Read())
				{
					if (sQLiteDataReader["UID"].ToString() == uid)
					{
						result = sQLiteDataReader["UID"].ToString() + "|" + sQLiteDataReader["PASS"].ToString() + "|" + sQLiteDataReader["2FA"].ToString() + "|" + sQLiteDataReader["COOKIE"].ToString() + "|" + sQLiteDataReader["TOKEN"].ToString() + "|" + sQLiteDataReader["EMAIL"].ToString() + "|" + sQLiteDataReader["PASSMAIL"].ToString() + "|" + sQLiteDataReader["UA"].ToString() + "|" + sQLiteDataReader["SINHNHAT"].ToString() + "|" + sQLiteDataReader["GENDER"].ToString() + "|" + sQLiteDataReader["FRIEND"].ToString() + "|" + sQLiteDataReader["GROUP"].ToString() + "|" + sQLiteDataReader["LIVE"].ToString() + "|" + sQLiteDataReader["GHICHU"].ToString() + "|" + sQLiteDataReader["LASTACTIVE"].ToString() + "|" + sQLiteDataReader["CATELOGE"].ToString() + "|" + sQLiteDataReader["PROXY"].ToString() + "|" + sQLiteDataReader["TRANGTHAI"].ToString();
					}
				}
			}
			sQLiteConnection.Dispose();
			return result;
		}

		public static List<string> getlistdanhmuc(string cateloge)
		{
			List<string> list = new List<string>();
			SQLiteConnection sQLiteConnection = new SQLiteConnection();
			sQLiteConnection.ConnectionString = "Data Source=Database\\Data.sqlite3;Version=3;";
			sQLiteConnection.Open();
			using (SQLiteConnection sQLiteConnection2 = sQLiteConnection)
			{
				using SQLiteCommand sQLiteCommand = sQLiteConnection2.CreateCommand();
				sQLiteCommand.CommandText = "SELECT * From [data]";
				sQLiteCommand.CommandType = CommandType.Text;
				SQLiteDataReader sQLiteDataReader = sQLiteCommand.ExecuteReader();
				bool flag;
				while (flag = sQLiteDataReader.Read())
				{
					if (sQLiteDataReader["CATELOGE"].ToString() == cateloge)
					{
						list.Add(sQLiteDataReader["UID"].ToString());
					}
				}
			}
			sQLiteConnection.Dispose();
			return list;
		}
	}
}
