namespace CloneFacebook.Server.DataPost
{
	public class DataDownloadImage
	{
		public int Index { get; set; }

		public string License { get; set; }

		public string Token { get; set; }

		public string Uid { get; set; }

		public string Proxy { get; set; }
	}
}
