namespace CloneFacebook.Server.DataPost
{
	public class DataAuthentication
	{
		public string Text { get; set; }
	}
}
