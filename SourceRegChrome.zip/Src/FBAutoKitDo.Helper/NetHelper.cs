using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using xNet;

namespace FBAutoKitDo.Helper
{
	internal class NetHelper
	{
		private readonly HttpRequest Request;

		internal NetHelper(string cookie = "", string userAgent = "", string proxy = "")
		{
			bool flag = userAgent == "";
			bool flag2 = cookie != "";
			bool flag3 = proxy != "";
			if (flag)
			{
				string[] array = null;
				if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "UserAgent.txt"))
				{
					array = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "UserAgent.txt").ToArray();
				}
				if (array.Length == 0)
				{
					array = new string[21]
					{
						"Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/69.0.3497.105 Mobile/15E148 Safari/605.1", "Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/13.2b11866 Mobile/16A366 Safari/605.1.15", "Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1", "Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1", "Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A5370a Safari/604.1", "Mozilla/5.0 (iPhone9,3; U; CPU iPhone OS 10_0_1 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/14A403 Safari/602.1", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
						"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.83 Safari/537.1", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36",
						"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
					};
				}
				Random random = new Random();
				userAgent = array[random.Next(0, array.Length)].ToString();
			}
			if (userAgent.Contains("no"))
			{
				userAgent = "";
			}
			Request = new HttpRequest
			{
				KeepAlive = true,
				AllowAutoRedirect = true,
				Cookies = new CookieDictionary(),
				UserAgent = userAgent
			};
			Request.AddHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			Request.AddHeader("Accept-Language", "en-GB,en;q=0.9,vi-VN;q=0.8,vi;q=0.7,en-US;q=0.6");
			if (flag2)
			{
				List<string> list = new List<string>();
				string[] array2 = cookie.Split(';');
				string[] array3 = array2;
				string[] array4 = array3;
				foreach (string text in array4)
				{
					string[] array5 = text.Split('=');
					if (!list.Contains(array5[0].ToString()))
					{
						list.Add(array5[0].ToString());
						if (array5.Count() >= 2 && (array5[0].Contains("sb") || array5[0].Contains("c_user") || array5[0].Contains("datr") || array5[0].Contains("locale") || array5[0].Contains("xs") || array5[0].Contains("spin") || array5[0].Contains("presence") || array5[0].Contains("fr") || array5[0].Contains("wd")))
						{
							Request.Cookies.Add(array5[0].Trim(), array5[1].Trim());
						}
					}
				}
			}
			if (flag3)
			{
				switch (proxy.Split(':').Count())
				{
				case 1:
					Request.Proxy = new HttpProxyClient("127.0.0.1:", Convert.ToInt32(proxy));
					break;
				case 2:
					Request.Proxy = HttpProxyClient.Parse(proxy);
					break;
				case 4:
					Request.Proxy = new HttpProxyClient(proxy.Split(':')[0], Convert.ToInt32(proxy.Split(':')[1]), proxy.Split(':')[2], proxy.Split(':')[3]);
					break;
				case 3:
					break;
				}
			}
		}

		internal string RequestGet(string Url, string Referer = "", string ContentType = "")
		{
			if (Referer != "")
			{
				Request.AddHeader("Referer", Referer);
			}
			if (ContentType == "")
			{
				ContentType = "application/x-www-form-urlencoded";
			}
			Request.AddHeader("ContentType", ContentType);
			string text = "";
			try
			{
				return Request.Get(Url).ToString();
			}
			catch
			{
				return "1";
			}
		}

		internal string RequestPost(string Url, string data = null, string Referer = "", string ContentType = "", string cook = "")
		{
			Request.AddHeader("authority", "mbasic.facebook.com");
			Request.AddParam("Content-type", "application/x-www-form-urlencoded");
			Request.AddHeader("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			Request.AddHeader("accept-language", "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5");
			Request.AddHeader("Cookie", cook);
			Request.AddHeader("origin", "https://mbasic.facebook.com");
			if (Referer != "")
			{
				Request.AddHeader("Referer", Referer);
			}
			if (ContentType == "")
			{
				ContentType = "application/x-www-form-urlencoded";
			}
			Request.AddHeader("ContentType", ContentType);
			return Request.Post(Url, data, ContentType).ToString();
		}

		internal string RequestPost2(string Url, string data = null, string Referer = "", string ContentType = "")
		{
			if (Referer != "")
			{
				Request.AddHeader("Referer", Referer);
			}
			if (ContentType == "")
			{
				ContentType = "application/x-www-form-urlencoded";
			}
			Request.AddHeader("ContentType", ContentType);
			return Request.Post(Url, data, ContentType).ToString();
		}

		internal string Cookie()
		{
			return Request.Cookies.ToString();
		}

		internal string CheckIP()
		{
			int num = 0;
			while (true)
			{
				try
				{
					string text = RequestGet("http://ipinfo.io/ip");
					string text2 = text;
					if ((!(text2 != "") && text2 == null) || !text2.Contains("."))
					{
						continue;
					}
					return text2;
				}
				catch
				{
					num++;
					if (num == 5)
					{
						return "";
					}
					Thread.Sleep(2000);
				}
			}
		}

		public static void resetDcom(string tendcom)
		{
			Process process = new Process();
			process.StartInfo.FileName = "rasdial.exe";
			process.StartInfo.Arguments = "\"" + tendcom + "\" /disconnect";
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.RedirectStandardError = true;
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			process.Start();
			process.WaitForExit();
			Thread.Sleep(1000);
		}

		public static void startDcom(string tendcom)
		{
			Thread.Sleep(1000);
			Process process = new Process();
			process.StartInfo.FileName = "rasdial.exe";
			process.StartInfo.Arguments = "\"" + tendcom + "\"";
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.RedirectStandardError = true;
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			process.Start();
			process.WaitForExit();
			Thread.Sleep(1000);
		}

		internal void Dispose()
		{
			Request?.Dispose();
		}
	}
}
