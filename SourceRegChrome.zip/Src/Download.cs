﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

public class Download : Form
{ 
	private string string_0 = "";

	private string string_1 = "";

	private IContainer D681BFB4 = null;

	private Label BA0AD82F;

	private ProgressBar CB0E37A5;

	public Download(string C816E2BF)
	{
		InitializeComponent(); 
		string_0 = C816E2BF;
		string_1 = Path.GetFileName(string_0);
	}

	 

	private void Download_Load(object sender, EventArgs e)
	{
		try
		{
			ServicePointManager.Expect100Continue = true;
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			if (Class48.BEB0E2AC())
			{
				Uri uri_ = new Uri(string_0);
				Helper.A4251B2A("download");
				Helper.smethod_25("download");
				method_2(uri_, "download\\" + string_1);
			}
			else
			{
				MessageBox.Show("Không co\u0301 kê\u0301t nô\u0301i Internet, vui lo\u0300ng kiê\u0309m tra la\u0323i!");
				Close();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("Error: " + ex.Message);
			Close();
		}
	}

	public void method_0(string E31FA429, string string_2)
	{
		DirectoryInfo eB0D7A8F = new DirectoryInfo(E31FA429);
		DirectoryInfo eEA12B0E = new DirectoryInfo(string_2);
		method_1(eB0D7A8F, eEA12B0E);
	}

	public void method_1(DirectoryInfo EB0D7A8F, DirectoryInfo EEA12B0E)
	{
		Directory.CreateDirectory(EEA12B0E.FullName);
		int num = 1;
		FileInfo[] files = EB0D7A8F.GetFiles();
		foreach (FileInfo fileInfo in files)
		{
			Application.DoEvents();
			fileInfo.CopyTo(Path.Combine(EEA12B0E.FullName, fileInfo.Name), overwrite: true);
			num++;
		}
		DirectoryInfo[] directories = EB0D7A8F.GetDirectories();
		foreach (DirectoryInfo directoryInfo in directories)
		{
			DirectoryInfo eEA12B0E = EEA12B0E.CreateSubdirectory(directoryInfo.Name);
			method_1(directoryInfo, eEA12B0E);
		}
	}

	private void method_2(Uri uri_0, string string_2)
	{
		Thread thread = new Thread((ThreadStart)delegate
		{
			WebClient webClient = new WebClient();
			webClient.DownloadProgressChanged += method_3;
			webClient.DownloadFileCompleted += C41FA1A5;
			webClient.DownloadFileAsync(uri_0, string_2);
		});
		thread.IsBackground = true;
		thread.Start();
	}

	private void method_3(object sender, DownloadProgressChangedEventArgs e)
	{
		BeginInvoke((MethodInvoker)delegate
		{
			double num = double.Parse(e.BytesReceived.ToString());
			double num2 = double.Parse(e.TotalBytesToReceive.ToString());
			double d = num / num2 * 100.0;
			BA0AD82F.Text = $"Downloading ({int.Parse(Math.Truncate(d).ToString())}%)...";
			CB0E37A5.Value = int.Parse(Math.Truncate(d).ToString());
		});
	}

	private void C41FA1A5(object sender, AsyncCompletedEventArgs e)
	{
		 
		try
		{
			ZipFile.ExtractToDirectory("./download/" + string_1, "./download/");
			Helper.A1A04C36("./download/" + string_1);
			method_0("download", "./");
			Helper.A4251B2A("download");
			BeginInvoke((MethodInvoker)delegate
			{
				Close();
			});
		}
		catch (Exception ex)
		{
			MessageBox.Show("Error: " + ex.Message);
			BeginInvoke((MethodInvoker)delegate
			{
				Close();
			});
		}
	}

	protected override void Dispose(bool B71DA6A9)
	{
		if (B71DA6A9 && D681BFB4 != null)
		{
			D681BFB4.Dispose();
		}
		base.Dispose(B71DA6A9);
	}

	private void InitializeComponent()
	{
		this.BA0AD82F = new System.Windows.Forms.Label();
		this.CB0E37A5 = new System.Windows.Forms.ProgressBar();
		base.SuspendLayout();
		this.BA0AD82F.AutoSize = true;
		this.BA0AD82F.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.BA0AD82F.Location = new System.Drawing.Point(34, 22);
		this.BA0AD82F.Name = "lblproccess";
		this.BA0AD82F.Size = new System.Drawing.Size(125, 16);
		this.BA0AD82F.TabIndex = 1;
		this.BA0AD82F.Text = "Downloading (0%)...";
		this.CB0E37A5.Location = new System.Drawing.Point(37, 52);
		this.CB0E37A5.Name = "progressBar1";
		this.CB0E37A5.Size = new System.Drawing.Size(219, 23);
		this.CB0E37A5.TabIndex = 2;
		base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
		this.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
		base.ClientSize = new System.Drawing.Size(294, 104);
		base.Controls.Add(this.CB0E37A5);
		base.Controls.Add(this.BA0AD82F);
		this.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
		base.Name = "fDownloadFile";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "frm_progress";
		base.Load += new System.EventHandler(Download_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
 
}
