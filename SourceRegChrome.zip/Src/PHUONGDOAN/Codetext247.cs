using System.Text.RegularExpressions;
using RestSharp;

namespace PHUONGDOAN
{
	public class Codetext247
	{
		public string Getphone(string api)
		{
			string result = "";
			string baseUrl = "https://administrator.codetext247.com/api/sim-request?token=" + api + "&service=19";
			try
			{
				RestClient restClient = new RestClient(baseUrl);
				restClient.Timeout = -1;
				RestRequest restRequest = new RestRequest(Method.GET);
				restRequest.AddHeader("Content-Type", "application/x-www-form-urlencoded");
				IRestResponse restResponse = restClient.Execute(restRequest);
				string content = restResponse.Content;
				if (content.Contains("phone_out"))
				{
					return "";
				}
				string value = Regex.Match(content, "phone\" : \"(\\d+)").Groups[1].Value;
				string value2 = Regex.Match(content, "id\" : (\\d+)").Groups[1].Value;
				result = value + "|" + value2;
			}
			catch
			{
			}
			return result;
		}

		public string Getcode(string api, string phone)
		{
			string text = "";
			if (phone.Contains("+84"))
			{
				phone = phone.Replace("+84", "0");
			}
			string baseUrl = "https://administrator.codetext247.com/api/get-message?token=" + api + "&phone=" + phone;
			try
			{
				RestClient restClient = new RestClient(baseUrl);
				restClient.Timeout = -1;
				RestRequest restRequest = new RestRequest(Method.GET);
				restRequest.AddHeader("Content-Type", "application/x-www-form-urlencoded");
				IRestResponse restResponse = restClient.Execute(restRequest);
				string content = restResponse.Content;
				if (content.Contains("Phone not found"))
				{
					return "";
				}
				text = Regex.Match(content, "Use (\\d+)").Groups[1].Value;
				if (text == "")
				{
					text = Regex.Match(content, "message\" : \"(\\d{5,6})").Groups[1].Value;
				}
			}
			catch
			{
				return text;
			}
			return text;
		}
	}
}
