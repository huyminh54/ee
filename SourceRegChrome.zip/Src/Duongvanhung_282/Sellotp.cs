using System.Text.RegularExpressions;
using RestSharp;

namespace Duongvanhung_282
{
	public class Sellotp
	{
		public string Getphone(string api)
		{
			string result = "";
			try
			{
				RestClient restClient = new RestClient("https://api.sellotp.com/request/get?token=" + api + "&serviceId=7");
				restClient.Timeout = -1;
				RestRequest restRequest = new RestRequest(Method.GET);
				restRequest.AddHeader("Content-Type", "application/x-www-form-urlencoded");
				IRestResponse restResponse = restClient.Execute(restRequest);
				string content = restResponse.Content;
				string value = Regex.Match(content, "\"phone_number(.*?)(\\d+)").Groups[2].Value;
				string value2 = Regex.Match(content, "request_id(.*?)(\\d+)").Groups[2].Value;
				if (value != "" && value2 != "")
				{
					result = value + "|" + value2;
				}
			}
			catch
			{
				return result;
			}
			return result;
		}

		public string Getcode(string api, string id)
		{
			string text = "";
			try
			{
				RestClient restClient = new RestClient("https://api.sellotp.com/session/get?token=" + api + "&requestId=" + id);
				restClient.Timeout = -1;
				RestRequest restRequest = new RestRequest(Method.GET);
				restRequest.AddHeader("Content-Type", "application/x-www-form-urlencoded");
				IRestResponse restResponse = restClient.Execute(restRequest);
				string content = restResponse.Content;
				text = Regex.Match(content, "SmsContent\":\"(\\d{6})").Groups[1].Value;
				if (text == "")
				{
					text = Regex.Match(content, "SmsContent\":\"(\\d{5})").Groups[1].Value;
				}
			}
			catch
			{
				return text;
			}
			return text;
		}
	}
}
