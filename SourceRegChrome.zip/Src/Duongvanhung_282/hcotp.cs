using System.Text.RegularExpressions;
using RestSharp;

namespace Duongvanhung_282
{
	public class hcotp
	{
		public string Getcode(string token, string id)
		{
			string result = string.Empty;
			try
			{
				RestClient restClient = new RestClient("http://hcotp.com/api/v2/getcode?token=" + token + "&requestId=" + id);
				restClient.Timeout = -1;
				RestRequest request = new RestRequest(Method.GET);
				IRestResponse restResponse = restClient.Execute(request);
				string content = restResponse.Content;
				result = Regex.Match(content, "code\":\"(.*?)\"").Groups[1].Value;
			}
			catch
			{
				return result;
			}
			return result;
		}

		public string Getphone(string api)
		{
			string result = string.Empty;
			try
			{
				RestClient restClient = new RestClient("http://hcotp.com/api/v2/createrequest?token=" + api + "&serviceId=1&carrier=all");
				restClient.Timeout = -1;
				RestRequest restRequest = new RestRequest(Method.GET);
				restRequest.AddHeader("Content-Type", "application/x-www-form-urlencoded");
				IRestResponse restResponse = restClient.Execute(restRequest);
				string content = restResponse.Content;
				string value = Regex.Match(content, "phoneNum(.*?)(\\d+)").Groups[2].Value;
				string value2 = Regex.Match(content, "id\":\"(.*?)\"").Groups[1].Value;
				if (value != "")
				{
					result = value + "|" + value2;
				}
			}
			catch
			{
				return result;
			}
			return result;
		}
	}
}
