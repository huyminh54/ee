using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using RestSharp;

namespace Duongvanhung_282
{
	public class Ndline
	{
		public string Getphone(string api)
		{
			string text = string.Empty;
			string empty = string.Empty;
			try
			{
				string requestUriString = "https://2ndline.io/apiv1/order?apikey=" + api + "&serviceId=275&allowVoiceSms=true";
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
				httpWebRequest.ContentType = "application/json";
				HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
				{
					string input = streamReader.ReadToEnd();
					text = Regex.Match(input, "id\":(\\d+)").Groups[1].Value;
					if (text == "" || text == null)
					{
						Thread.Sleep(500);
						return "";
					}
					streamReader.Dispose();
				}
				while (true)
				{
					string requestUriString2 = "https://2ndline.io/apiv1/ordercheck?apikey=" + api + "&id=" + text;
					HttpWebRequest httpWebRequest2 = (HttpWebRequest)WebRequest.Create(requestUriString2);
					httpWebRequest2.ContentType = "application/json";
					HttpWebResponse httpWebResponse2 = (HttpWebResponse)httpWebRequest2.GetResponse();
					using (StreamReader streamReader2 = new StreamReader(httpWebResponse2.GetResponseStream()))
					{
						string input2 = streamReader2.ReadToEnd();
						empty = Regex.Match(input2, "phone\":\"(\\d+)").Groups[1].Value;
						if (empty != "" && empty != null)
						{
							return empty + "|" + text;
						}
						streamReader2.Dispose();
					}
					Thread.Sleep(1000);
				}
			}
			catch
			{
				return "";
			}
		}

		public string Getcode(string api, string id)
		{
			string text = "";
			try
			{
				string baseUrl = "https://2ndline.io/apiv1/ordercheck?apikey=" + api + "&id=" + id;
				RestClient restClient = new RestClient(baseUrl);
				restClient.Timeout = -1;
				RestRequest restRequest = new RestRequest(Method.GET);
				restRequest.AddHeader("Content-Type", "application/x-www-form-urlencoded");
				IRestResponse restResponse = restClient.Execute(restRequest);
				string content = restResponse.Content;
				text = Regex.Match(content, "code\":\"(\\d{6})").Groups[1].Value;
				if (text == "" || text == null)
				{
					text = Regex.Match(content, "code\":\"(\\d{5})").Groups[1].Value;
				}
			}
			catch
			{
				return text;
			}
			return text;
		}
	}
}
