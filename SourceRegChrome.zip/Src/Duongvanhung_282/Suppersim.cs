using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using RestSharp;

namespace Duongvanhung_282
{
	public class Suppersim
	{
		public string Getphone(string api)
		{
			string result = "";
			try
			{
				string baseUrl = "http://supersim247.com/api/phone/new-session?token=" + api + "&service=4&network=1,2,3,4,5";
				RestClient restClient = new RestClient(baseUrl);
				restClient.Timeout = -1;
				RestRequest restRequest = new RestRequest(Method.GET);
				restRequest.AddHeader("Content-Type", "application/x-www-form-urlencoded");
				IRestResponse restResponse = restClient.Execute(restRequest);
				string content = restResponse.Content;
				string value = Regex.Match(content, "phone_number\":\"(.*?)\"").Groups[1].Value;
				string value2 = Regex.Match(content, "session\":\"(.*?)\"").Groups[1].Value;
				if (value != "" && value2 != "")
				{
					result = value + "|" + value2;
				}
			}
			catch
			{
				return result;
			}
			return result;
		}

		public string Getcode2(string api, string id)
		{
			string result = "";
			try
			{
				string requestUriString = "http://supersim247.com/api/session/" + id + "/get-otp?token=" + api;
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
				httpWebRequest.Method = "GET";
				HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				using StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream());
				string text = streamReader.ReadToEnd();
				if (text != "" && text != null)
				{
					result = Regex.Match(text, "otp\":\"([0-9]{0,})").Groups[1].Value;
				}
			}
			catch
			{
				return result;
			}
			return result;
		}

		public string Getcode(string api, string id, string strProxy)
		{
			string text = "";
			try
			{
				string requestUriString = "http://supersim247.com/api/session/" + id + "/get-otp?token=" + api;
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
				httpWebRequest.Method = "GET";
				if (strProxy != "")
				{
					if (strProxy.Split(':').Length == 4)
					{
						httpWebRequest.Proxy = WebRequest.DefaultWebProxy;
						httpWebRequest.Credentials = new NetworkCredential(strProxy.Split(':')[2], strProxy.Split(':')[3]);
						httpWebRequest.Proxy.Credentials = new NetworkCredential(strProxy.Split(':')[2], strProxy.Split(':')[3]);
					}
					else if (strProxy.Split(':').Length == 2)
					{
						httpWebRequest.Proxy = new WebProxy(strProxy.Split(':')[0], int.Parse(strProxy.Split(':')[1]));
					}
				}
				HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				using StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream());
				string text2 = streamReader.ReadToEnd();
				if (text2 != "" && text2 != null)
				{
					text = Regex.Match(text2, "otp\":\"([0-9]{0,})").Groups[1].Value;
				}
			}
			catch
			{
				text = Getcode2(api, id);
				if (text != "" && text != null)
				{
					return text;
				}
			}
			return text;
		}
	}
}
