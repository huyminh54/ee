using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace CloneFacebook.Server
{
	// Token: 0x0200003B RID: 59
	public class RequestServer
	{
		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x0005C2DB File Offset: 0x0005A4DB
		// (set) Token: 0x060001B6 RID: 438 RVA: 0x0005C2E2 File Offset: 0x0005A4E2
		private static HttpClient _clientServer { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x0005C2EA File Offset: 0x0005A4EA
		// (set) Token: 0x060001B8 RID: 440 RVA: 0x0005C2F1 File Offset: 0x0005A4F1
		private static HttpClientHandler _handlerServer { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x0005C2F9 File Offset: 0x0005A4F9
		// (set) Token: 0x060001BA RID: 442 RVA: 0x0005C300 File Offset: 0x0005A500
		private static string _token { get; set; }

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060001BB RID: 443 RVA: 0x0005C308 File Offset: 0x0005A508
		// (set) Token: 0x060001BC RID: 444 RVA: 0x0005C30F File Offset: 0x0005A50F
		private static string _license { get; set; }

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060001BD RID: 445 RVA: 0x0005C317 File Offset: 0x0005A517
		// (set) Token: 0x060001BE RID: 446 RVA: 0x0005C31E File Offset: 0x0005A51E
		private static object _lockRequest { get; set; }

		// Token: 0x060001BF RID: 447 RVA: 0x0005C328 File Offset: 0x0005A528
		public static void InitParameterServer(string token = null)
		{
			RequestServer._handlerServer = new HttpClientHandler();
			RequestServer._clientServer = new HttpClient((HttpMessageHandler)RequestServer._handlerServer);
			RequestServer._lockRequest = new object();
			bool flag = !string.IsNullOrEmpty(token);
			if (flag)
			{
				RequestServer.SetToken(token);
			}
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0005C378 File Offset: 0x0005A578
		public static void SetLicense(string license)
		{
			object lockRequest = RequestServer._lockRequest;
			lock (lockRequest)
			{
				RequestServer._license = license;
			}
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0005C3C0 File Offset: 0x0005A5C0
		public static void SetToken(string token)
		{
			object lockRequest = RequestServer._lockRequest;
			lock (lockRequest)
			{
				RequestServer._token = token;
				bool flag2 = RequestServer._handlerServer == null && RequestServer._clientServer == null;
				if (flag2)
				{
					RequestServer.InitParameterServer(token);
				}
				else
				{
					HttpRequestHeaders defaultRequestHeaders = RequestServer._clientServer.DefaultRequestHeaders;
					bool flag3 = defaultRequestHeaders.Contains("Token");
					if (flag3)
					{
						defaultRequestHeaders.Remove("Token");
					}
					RequestServer._clientServer.DefaultRequestHeaders.TryAddWithoutValidation("Token", token);
				}
			}
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0005C468 File Offset: 0x0005A668
		public static string PostServer(string url, string data)
		{
			object lockRequest = RequestServer._lockRequest;
			string @string;
			lock (lockRequest)
			{
				RequestServer.PingServer();
				StringContent stringContent = new StringContent(data, Encoding.Default, "application/json");
				HttpResponseMessage result = RequestServer._clientServer.PostAsync(url, (HttpContent)stringContent).Result;
				byte[] result2 = result.Content.ReadAsByteArrayAsync().Result;
				@string = Encoding.UTF8.GetString(result2, 0, result2.Length);
			}
			return @string;
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x0005C4FC File Offset: 0x0005A6FC
		public static string GetServer(string url)
		{
			object lockRequest = RequestServer._lockRequest;
			string @string;
			lock (lockRequest)
			{
				RequestServer.PingServer();
				HttpResponseMessage result = RequestServer._clientServer.GetAsync(url).Result;
				byte[] result2 = result.Content.ReadAsByteArrayAsync().Result;
				@string = Encoding.UTF8.GetString(result2, 0, result2.Length);
			}
			return @string;
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x0005C574 File Offset: 0x0005A774
		private static void PingServer()
		{
			string text = string.Format(ServiceServer.Parse(APIAuthentication.Ping), RequestServer._license);
			HttpResponseMessage result = RequestServer._clientServer.GetAsync(text).Result;
			byte[] result2 = result.Content.ReadAsByteArrayAsync().Result;
			string @string = Encoding.UTF8.GetString(result2, 0, result2.Length);
		}
	}
}
