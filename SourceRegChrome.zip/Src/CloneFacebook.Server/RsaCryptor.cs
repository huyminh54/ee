using System;
using System.Security.Cryptography;
using System.Text;

namespace CloneFacebook.Server
{
	public class RsaCryptor
	{
		private static string KeyPublic = "<RSAKeyValue><Modulus>qYYbR7y6zXFq11RFqHACbx7vaZqkyH76fZkdEXRWNA97aPHfMxmZdVPAGOnTE8bOQDQpec2pmt+P+50t8rJV+SJ8EE/1WIK3SPApQzq1SdB5drnTs3qxCR/5HB02lqnJ/AdXTqULebnXBLr87HYBhdReBW5ZAMOrOXzwRocVLX0=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

		private static int dwKeySize = 2048;

		public static string Encrypt(string cipherText)
		{
			if (string.IsNullOrEmpty(cipherText))
			{
				return "";
			}
			using RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider(dwKeySize);
			byte[] bytes = Encoding.Default.GetBytes(cipherText);
			rSACryptoServiceProvider.FromXmlString(KeyPublic);
			byte[] inArray = rSACryptoServiceProvider.Encrypt(bytes, fOAEP: false);
			return Convert.ToBase64String(inArray);
		}
	}
}
