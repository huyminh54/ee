namespace CloneFacebook.Server
{
	public enum APIAuthentication
	{
		Login,
		Forgot,
		Ping,
		CloseToken
	}
}
