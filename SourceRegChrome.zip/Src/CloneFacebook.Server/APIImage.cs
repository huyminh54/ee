namespace CloneFacebook.Server
{
	public enum APIImage
	{
		BoredHumans,
		ThisPersonDoesNotExist,
		UnrealPerson,
		FakeFaceRest
	}
}
