using System.Collections.Generic;
using System.Linq;

namespace CloneFacebook.Server
{
	public class ServiceServer
	{
		private static string Domain = "http://103.156.91.82";

		private static Dictionary<APIAuthentication, string> _apiAuthentication = new Dictionary<APIAuthentication, string>
		{
			{
				APIAuthentication.Login,
				Domain + "/authen/login"
			},
			{
				APIAuthentication.Forgot,
				Domain + "/authen/forgot"
			},
			{
				APIAuthentication.Ping,
				Domain + "/authen/ping/{0}"
			},
			{
				APIAuthentication.CloseToken,
				Domain + "/authen/closeToken"
			}
		};

		private static Dictionary<APIImage, string> _apiImage = new Dictionary<APIImage, string>
		{
			{
				APIImage.BoredHumans,
				Domain + "/dowload/image"
			},
			{
				APIImage.ThisPersonDoesNotExist,
				Domain + "/dowload/image"
			},
			{
				APIImage.UnrealPerson,
				Domain + "/dowload/image"
			},
			{
				APIImage.FakeFaceRest,
				Domain + "/dowload/image"
			}
		};

		public static string Parse(APIAuthentication api)
		{
			return _apiAuthentication.FirstOrDefault((KeyValuePair<APIAuthentication, string> x) => x.Key == api).Value;
		}

		public static string Parse(APIImage api)
		{
			return _apiImage.FirstOrDefault((KeyValuePair<APIImage, string> x) => x.Key == api).Value;
		}

		public static string GetApiImage()
		{
			return Domain + "/dowload/image";
		}
	}
}
