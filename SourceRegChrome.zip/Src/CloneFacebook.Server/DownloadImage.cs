namespace CloneFacebook.Server
{
	public class DownloadImage
	{
	}
}
