namespace CloneFacebook.Server
{
	public class DataManager
	{
		public static string License { get; set; }

		public static string Status { get; set; }

		public static string Token { get; set; }

		public static string Expired { get; set; }
	}
}
