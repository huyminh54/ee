using System;

namespace CloneFacebook.Server
{
	public class TimeZoneHelper
	{
		private static string TimeZoneVietNamId = "SE Asia Standard Time";

		public static DateTimeOffset GetTimeZoneInfo()
		{
			TimeZoneInfo destinationTimeZone = TimeZoneInfo.FindSystemTimeZoneById(TimeZoneVietNamId);
			return TimeZoneInfo.ConvertTime(DateTime.Now, destinationTimeZone);
		}
	}
}
