using System;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using NLog;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace A_A_A
{
	public class XuanAction
	{
		private static Logger logger = LogManager.GetCurrentClassLogger();

		protected bool ByPassOneTrust(ChromeDriver chrome)
		{
			try
			{
				if (!WaitHtmlElement(chrome, 5, "thirdPartyFrame_permission_dialog"))
				{
					return false;
				}
				IWebElement frameElement = chrome.FindElement(By.Id("thirdPartyFrame_permission_dialog"));
				chrome.SwitchTo().Frame(frameElement);
				logger.Debug("Switched to thirdPartyFrame_permission_dialog");
				if (!WaitHtmlElement(chrome, 5, "permission-iframe"))
				{
					chrome.SwitchTo().DefaultContent();
					return false;
				}
				frameElement = chrome.FindElement(By.Id("permission-iframe"));
				chrome.SwitchTo().Frame(frameElement);
				if (!WaitHtmlElement(chrome, 5, "onetrust-accept-btn-handler"))
				{
					return true;
				}
				chrome.FindElement(By.Id("onetrust-accept-btn-handler")).Click();
				Thread.Sleep(2000);
			}
			catch (Exception value)
			{
				logger.Error(value);
				chrome.SwitchTo().DefaultContent();
				return false;
			}
			return true;
		}

		public string FindOptionByDomain(ChromeDriver chrome, string domain)
		{
			string attribute = chrome.FindElement(By.Name("fieldSet:fieldSet_body:grid:addressSelection:domainSelection")).GetAttribute("innerHTML");
			string pattern = "(option\\d+)\"(.*)>" + domain;
			Match match = Regex.Match(attribute, pattern);
			if (match.Success)
			{
				return match.Groups[1].Value;
			}
			return "option6";
		}

		public string FindOptionByDomain2(ChromeDriver chrome, string domain)
		{
			string attribute = chrome.FindElement(By.XPath("//select[@name='email_domain']")).GetAttribute("innerHTML");
			string pattern = "value=\"(.*?)\">@" + domain;
			Match match = Regex.Match(attribute, pattern);
			if (match.Success)
			{
				return match.Groups[1].Value;
			}
			return "option6";
		}

		public bool WaitHtmlElement(ChromeDriver chrome, int delay, string ele)
		{
			for (int i = 0; i < delay; i++)
			{
				try
				{
					Thread.Sleep(1000);
					if (chrome.PageSource.Contains(ele))
					{
						return true;
					}
				}
				catch (Exception)
				{
				}
			}
			return false;
		}

		public static void QuitChrome(ChromeDriver chrome)
		{
			try
			{
				chrome.Quit();
			}
			catch
			{
			}
		}

		[Obsolete]
		public ReadOnlyCollection<IWebElement> WaitlLoadElements(ChromeDriver _driver, By elementLocator, TimeSpan span)
		{
			try
			{
				Task.Delay(TimeSpan.FromSeconds(1.0)).Wait();
				WebDriverWait webDriverWait = new WebDriverWait(_driver, span);
				return webDriverWait.Until((IWebDriver drv) => drv.FindElements(elementLocator));
			}
			catch (Exception)
			{
				return null;
			}
		}

		[Obsolete]
		public bool SendKey(ChromeDriver driver, By elementLocator, TimeSpan span, string text)
		{
			Task.Delay(TimeSpan.FromSeconds(1.0)).Wait();
			IWebElement webElement = WaitlLoadElement(driver, elementLocator, span);
			if (webElement != null)
			{
				Actions actions = new Actions(driver);
				actions.MoveToElement(webElement).Click(webElement).Perform();
				Task.Delay(TimeSpan.FromSeconds(1.0)).Wait();
				webElement.Clear();
				Task.Delay(TimeSpan.FromSeconds(2.0)).Wait();
				for (int i = 0; i < text.Length; i++)
				{
					webElement.SendKeys(text[i].ToString());
					Task.Delay(TimeSpan.FromSeconds(0.3));
				}
				Task.Delay(TimeSpan.FromSeconds(3.0));
				return true;
			}
			Task.Delay(TimeSpan.FromSeconds(3.0));
			return false;
		}

		[Obsolete]
		public bool Clicks(ChromeDriver driver, By elementLocator, TimeSpan span, int index)
		{
			Task.Delay(TimeSpan.FromSeconds(1.0)).Wait();
			ReadOnlyCollection<IWebElement> readOnlyCollection = WaitlLoadElements(driver, elementLocator, span);
			if (readOnlyCollection.Count != 0)
			{
				Actions actions = new Actions(driver);
				actions.MoveToElement(readOnlyCollection[index]).Click(readOnlyCollection[index]).Perform();
				Task.Delay(TimeSpan.FromSeconds(3.0));
				return true;
			}
			Task.Delay(TimeSpan.FromSeconds(3.0));
			return false;
		}

		[Obsolete]
		public bool ClickElement(ChromeDriver driver, By elementLocator, TimeSpan span)
		{
			Task.Delay(TimeSpan.FromSeconds(1.0)).Wait();
			IWebElement webElement = WaitlLoadElement(driver, elementLocator, span);
			if (webElement != null)
			{
				Actions actions = new Actions(driver);
				actions.MoveToElement(webElement).Click(webElement).Perform();
				Task.Delay(TimeSpan.FromSeconds(3.0));
				return true;
			}
			Task.Delay(TimeSpan.FromSeconds(3.0));
			return false;
		}

		[Obsolete]
		public IWebElement WaitlLoadElement(ChromeDriver _driver, By elementLocator, TimeSpan span)
		{
			try
			{
				Task.Delay(TimeSpan.FromSeconds(1.0)).Wait();
				WebDriverWait webDriverWait = new WebDriverWait(_driver, span);
				return webDriverWait.Until((IWebDriver drv) => drv.FindElement(elementLocator));
			}
			catch (Exception)
			{
				return null;
			}
		}

		[Obsolete]
		public bool Goto(ChromeDriver driver, string url, TimeSpan span)
		{
			Task.Delay(TimeSpan.FromSeconds(4.0)).Wait();
			return WaitlLoadPageSrouce(driver, delegate
			{
				driver.Url = url;
			}, span);
		}

		[Obsolete]
		public bool WaitlLoadPageSrouce(ChromeDriver _driver, Action doing, TimeSpan span)
		{
			Task.Delay(TimeSpan.FromSeconds(1.0)).Wait();
			IWebElement oldPage = _driver.FindElement(By.TagName("html"));
			doing();
			WebDriverWait webDriverWait = new WebDriverWait(_driver, span);
			try
			{
				object obj = webDriverWait.Until((IWebDriver driver) => ExpectedConditions.StalenessOf(oldPage)(_driver) && ((IJavaScriptExecutor)driver).ExecuteScript("return document.readyState").Equals("complete"));
				Task.Delay(TimeSpan.FromSeconds(1.5)).Wait();
				return true;
			}
			catch (Exception)
			{
				return false;
			}
		}
	}
}
