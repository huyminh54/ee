using System.Text.RegularExpressions;
using System.Threading;
using AE.Net.Mail;

namespace A_A_A
{
	public class Mail
	{
		public string Verify(string email, string pass, string ipmap, int port)
		{
			string text = "";
			using (ImapClient imapClient = new ImapClient())
			{
				int num = 0;
				while (true)
				{
					bool flag = true;
					while (true)
					{
						IL_0016:
						try
						{
							imapClient.Connect(ipmap, port, ssl: true, skipSslValidation: false);
							try
							{
								imapClient.Login(email, pass);
							}
							catch
							{
							}
							imapClient.SelectMailbox("INBOX");
							int num2 = 0;
							int messageCount = imapClient.GetMessageCount();
							while (true)
							{
								if (messageCount < 2)
								{
									Thread.Sleep(1000);
									imapClient.SelectMailbox("INBOX");
									num2++;
									if (num2 == 10)
									{
										break;
									}
									messageCount = imapClient.GetMessageCount();
									continue;
								}
								MailMessage[] messages = imapClient.GetMessages(messageCount - 1, messageCount - 1, headersonly: false);
								MailMessage[] array = messages;
								MailMessage[] array2 = array;
								foreach (MailMessage mailMessage in array2)
								{
									string body = mailMessage.Body;
									if (body.Contains("Xác nhận") || body.Contains("confirm") || body.Contains("Facebook") || body.Contains("facebook"))
									{
										text = Regex.Match(body, "mã xác nhận này:(\r\n\r\n)([0-9]{0,})").Groups[2].Value;
										if (text == "")
										{
											text = Regex.Match(body, "confirmation code: ([0-9]{0,})").Groups[1].Value;
										}
										if (text == "")
										{
											text = Regex.Match(body, "mã xác nhận sau: ([0-9]{0,})").Groups[1].Value;
										}
										if (text == "")
										{
											text = Regex.Match(body, "code=(\\d{5,6})").Groups[1].Value;
										}
										if (text == "")
										{
											text = Regex.Match(body, "c=(\\d{5,6})").Groups[1].Value;
										}
									}
								}
								imapClient.Dispose();
								if (text == "")
								{
									goto IL_0016;
								}
								break;
							}
						}
						catch
						{
							if (num == 10)
							{
								goto end_IL_0241;
							}
							num++;
							break;
						}
						goto end_IL_0241;
					}
					continue;
					end_IL_0241:
					break;
				}
			}
			return text;
		}
	}
}
