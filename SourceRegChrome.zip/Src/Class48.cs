using System.Runtime.InteropServices;

internal class Class48
{
	[DllImport("wininet.dll")]
	private static extern bool InternetGetConnectedState(out int int_0, int int_1);

	public static bool BEB0E2AC()
	{
		int int_;
		return InternetGetConnectedState(out int_, 0);
	}
}
