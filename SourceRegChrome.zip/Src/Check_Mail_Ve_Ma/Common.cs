using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Leaf.xNet;

namespace Check_Mail_Ve_Ma
{
	public static class Common
	{
		private static readonly Random rand = new Random();

		public static long CurrentSeconds => DateTimeOffset.Now.ToUnixTimeSeconds();

		public static string GetValueByRegex(string text, string pattern, int groupIndex = 1)
		{
			Match match = Regex.Match(text, pattern);
			if (!match.Success)
			{
				return string.Empty;
			}
			return match.Groups[groupIndex].Value;
		}

		public static ProxyType GetProxyTypeFromCombo(ComboBox combo)
		{
			ProxyType result = ProxyType.NONE;
			string text = combo.SelectedItem?.ToString();
			if (text == ProxyType.DCOM.GetStringValue())
			{
				result = ProxyType.DCOM;
			}
			else if (text == ProxyType.HMA.GetStringValue())
			{
				result = ProxyType.HMA;
			}
			else if (text == ProxyType.PROXY911.GetStringValue())
			{
				result = ProxyType.PROXY911;
			}
			else if (text == ProxyType.SOCKS4.GetStringValue())
			{
				result = ProxyType.SOCKS4;
			}
			else if (text == ProxyType.SOCKS5.GetStringValue())
			{
				result = ProxyType.SOCKS5;
			}
			else if (text == ProxyType.SSH.GetStringValue())
			{
				result = ProxyType.SSH;
			}
			else if (text == ProxyType.PROTON_VPN.GetStringValue())
			{
				result = ProxyType.PROTON_VPN;
			}
			else if (text == ProxyType.HTTP_PROXY.GetStringValue())
			{
				result = ProxyType.HTTP_PROXY;
			}
			else if (text == ProxyType.TIN_SOFT.GetStringValue())
			{
				result = ProxyType.TIN_SOFT;
			}
			else if (text == ProxyType.AWM_PROXY.GetStringValue())
			{
				result = ProxyType.AWM_PROXY;
			}
			else if (text == ProxyType.NORD_VPN.GetStringValue())
			{
				result = ProxyType.NORD_VPN;
			}
			else if (text == ProxyType.FAST_VPN.GetStringValue())
			{
				result = ProxyType.FAST_VPN;
			}
			else if (text == ProxyType.DA_PROXY.GetStringValue())
			{
				result = ProxyType.DA_PROXY;
			}
			return result;
		}

		public static bool IsValidProxy(string proxy, ProxyType proxyType)
		{
			try
			{
				if (string.IsNullOrWhiteSpace(proxy))
				{
					return true;
				}
				ProxyClient proxy2 = ParseProxy(proxy, proxyType);
				EzHttpRequest.Instance.Get("https://www.facebook.com", proxy2, ignoreError: false, 10000);
				return true;
			}
			catch
			{
			}
			return false;
		}

		public static ProxyClient ParseProxy(string strProxy, ProxyType proxyType)
		{
			ProxyClient proxyClient = null;
			if (!string.IsNullOrEmpty(strProxy) && proxyType != 0)
			{
				strProxy = strProxy.Trim();
				switch (proxyType)
				{
				case ProxyType.PROXY911:
				case ProxyType.SOCKS5:
				case ProxyType.SSH:
				{
					string[] array2 = strProxy.Split(':');
					if (array2.Length >= 4)
					{
						proxyClient = Socks5ProxyClient.Parse(array2[0] + ":" + array2[1]);
						proxyClient.Username = array2[2].Trim();
						proxyClient.Password = array2[3].Trim();
					}
					else
					{
						proxyClient = Socks5ProxyClient.Parse(strProxy);
					}
					break;
				}
				case ProxyType.HTTP_PROXY:
				case ProxyType.TIN_SOFT:
				case ProxyType.AWM_PROXY:
				{
					string[] array3 = strProxy.Split(':');
					if (array3.Length >= 4)
					{
						proxyClient = HttpProxyClient.Parse(array3[0] + ":" + array3[1]);
						proxyClient.Username = array3[2].Trim();
						proxyClient.Password = array3[3].Trim();
					}
					else
					{
						proxyClient = HttpProxyClient.Parse(strProxy);
					}
					break;
				}
				case ProxyType.DA_PROXY:
				{
					string[] array = strProxy.Split('^');
					if (array.Length < 2)
					{
						return null;
					}
					if (array[1] == ProxyType.SOCKS5.ToString())
					{
						return ParseProxy(array[0], ProxyType.SOCKS5);
					}
					if (array[1] == ProxyType.HTTP_PROXY.ToString())
					{
						return ParseProxy(array[0], ProxyType.HTTP_PROXY);
					}
					break;
				}
				}
				return proxyClient;
			}
			return proxyClient;
		}

		public static T GetRandomInList<T>(List<T> list)
		{
			if (list != null && list.Count != 0)
			{
				return list[rand.Next(list.Count)];
			}
			return default(T);
		}

		public static List<string> GetAwmProxyList(string key)
		{
			string url = "https://xlistlink.com/proxy/" + key;
			if (key.Contains("."))
			{
				url = key;
			}
			List<string> result = new List<string>();
			string text = EzHttpRequest.Instance.Get(url, null, null, 0);
			if (!text.Contains("ERROR"))
			{
				result = (from line in text.Split('\n')
					select line.Trim()).ToList();
			}
			return result;
		}
	}
}
