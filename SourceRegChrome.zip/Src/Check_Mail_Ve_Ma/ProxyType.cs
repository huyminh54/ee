namespace Check_Mail_Ve_Ma
{
	public enum ProxyType
	{
		[StringValue("None")]
		NONE,
		[StringValue("Dcom")]
		DCOM,
		[StringValue("HMA")]
		HMA,
		[StringValue("911 Proxy")]
		PROXY911,
		[StringValue("Socks 4")]
		SOCKS4,
		[StringValue("Socks 5")]
		SOCKS5,
		[StringValue("SSH")]
		SSH,
		[StringValue("Proton VPN")]
		PROTON_VPN,
		[StringValue("HTTP Proxy")]
		HTTP_PROXY,
		[StringValue("Tinsoft Proxy")]
		TIN_SOFT,
		[StringValue("AWM Proxy")]
		AWM_PROXY,
		[StringValue("Nord VPN")]
		NORD_VPN,
		[StringValue("FastVPN")]
		FAST_VPN,
		[StringValue("DA Proxy")]
		DA_PROXY
	}
}
