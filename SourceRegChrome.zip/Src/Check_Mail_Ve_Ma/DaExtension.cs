using System;
using System.Collections.Generic;
using System.Linq;

namespace Check_Mail_Ve_Ma
{
	public static class DaExtension
	{
		public static IEnumerable<T> EmptyIfNull<T>(this IEnumerable<T> source)
		{
			return source ?? Enumerable.Empty<T>();
		}

		public static bool In<T>(this T obj, params T[] args)
		{
			return args.Contains(obj);
		}

		public static string GetStringValue(this Enum value)
		{
			StringValueAttribute[] array = value.GetType().GetField(value.ToString()).GetCustomAttributes(typeof(StringValueAttribute), inherit: false) as StringValueAttribute[];
			if (array.Length == 0)
			{
				return null;
			}
			return array[0].StringValue;
		}
	}
}
