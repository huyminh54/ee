using System.Collections.Generic;
using Leaf.xNet;

namespace Check_Mail_Ve_Ma
{
	public class EzHttpRequest
	{
		private const int DEFAULT_TIMEOUT = 60000;

		private static EzHttpRequest _instance = new EzHttpRequest();

		public static EzHttpRequest Instance => _instance;

		private EzHttpRequest()
		{
		}

		public string Get(string url, ProxyClient proxy, Dictionary<string, string> headers = null, int timeout = 0)
		{
			using HttpRequest httpRequest = new HttpRequest();
			httpRequest.IgnoreProtocolErrors = true;
			httpRequest.AllowAutoRedirect = true;
			httpRequest.ConnectTimeout = 60000;
			httpRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36";
			httpRequest.Proxy = proxy;
			if (timeout != 0)
			{
				httpRequest.ConnectTimeout = timeout;
			}
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> header in headers)
				{
					httpRequest.AddHeader(header.Key, header.Value);
				}
			}
			return httpRequest.Get(url).ToString();
		}

		public string Get(string url, string proxy)
		{
			using HttpRequest httpRequest = new HttpRequest();
			httpRequest.IgnoreProtocolErrors = true;
			httpRequest.AllowAutoRedirect = true;
			httpRequest.ConnectTimeout = 60000;
			httpRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36";
			if (!string.IsNullOrWhiteSpace(proxy))
			{
				httpRequest.Proxy = HttpProxyClient.Parse(proxy);
			}
			return httpRequest.Get(url).ToString();
		}

		public string Get(string url, ProxyClient proxy, bool ignoreError = false, int timeout = 0, Dictionary<string, string> headers = null, string ua = "")
		{
			using HttpRequest httpRequest = new HttpRequest();
			httpRequest.UserAgent = ((!string.IsNullOrWhiteSpace(ua)) ? ua : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36");
			httpRequest.ConnectTimeout = ((timeout != 0) ? timeout : 60000);
			httpRequest.AllowAutoRedirect = true;
			httpRequest.IgnoreProtocolErrors = ignoreError;
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> header in headers)
				{
					httpRequest.AddHeader(header.Key, header.Value);
				}
			}
			if (proxy != null)
			{
				httpRequest.Proxy = proxy;
			}
			return httpRequest.Get(url).ToString();
		}

		public CookieStorage GetCookie(string url, ProxyClient proxy, Dictionary<string, string> headers = null)
		{
			using HttpRequest httpRequest = new HttpRequest();
			httpRequest.IgnoreProtocolErrors = true;
			httpRequest.AllowAutoRedirect = true;
			httpRequest.ConnectTimeout = 60000;
			httpRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36";
			if (proxy != null)
			{
				httpRequest.Proxy = proxy;
			}
			return httpRequest.Get(url).Cookies;
		}

		public string Post(string url, string body, string contentType, Dictionary<string, string> headers = null, ProxyClient proxy = null, bool ignoreError = true, string ua = "")
		{
			using HttpRequest httpRequest = new HttpRequest();
			httpRequest.IgnoreProtocolErrors = ignoreError;
			httpRequest.AllowAutoRedirect = true;
			httpRequest.ConnectTimeout = 60000;
			httpRequest.UserAgent = ((ua != string.Empty) ? ua : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36");
			if (proxy != null)
			{
				httpRequest.Proxy = proxy;
			}
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> header in headers)
				{
					httpRequest.AddHeader(header.Key, header.Value);
				}
			}
			return httpRequest.Post(url, body, contentType).ToString();
		}

		public byte[] Download(string url)
		{
			using HttpRequest httpRequest = new HttpRequest();
			return httpRequest.Get(url).ToBytes();
		}

		public void Download(string url, string localPath)
		{
			using HttpRequest httpRequest = new HttpRequest();
			httpRequest.IgnoreProtocolErrors = true;
			httpRequest.ConnectTimeout = 300000;
			httpRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36";
			httpRequest.Get(url).ToFile(localPath);
		}
	}
}
