using System.Collections.Generic;

namespace Check_Mail_Ve_Ma
{
	public class EzHttpHeaderBuilder
	{
		private readonly Dictionary<string, string> headers = new Dictionary<string, string>();

		public string UserAgent
		{
			set
			{
				headers["user-agent"] = value;
			}
		}

		public string FetchDest
		{
			set
			{
				headers["sec-fetch-dest"] = value;
			}
		}

		public string FetchMode
		{
			set
			{
				headers["sec-fetch-mode"] = value;
			}
		}

		public string FetchSite
		{
			set
			{
				headers["sec-fetch-site"] = value;
			}
		}

		public string FetchUser
		{
			set
			{
				headers["sec-fetch-user"] = value;
			}
		}

		public Dictionary<string, string> Build => headers;

		public EzHttpHeaderBuilder Cookie(string cookie)
		{
			headers["cookie"] = cookie;
			return this;
		}

		public EzHttpHeaderBuilder Add(string key, string value)
		{
			headers[key] = value;
			return this;
		}

		public EzHttpHeaderBuilder AjaxHeader()
		{
			FetchDest = "empty";
			FetchMode = "cors";
			FetchSite = "same-origin";
			return this;
		}

		public EzHttpHeaderBuilder NormalHeader()
		{
			FetchUser = "?1";
			FetchDest = "document";
			FetchMode = "navigate";
			FetchSite = "none";
			return this;
		}
	}
}
